# THIS REPOSITORY IS NO LONGER BEING MAINTAINED

The content is now being maintained by the jQuery Project at the [learn.jquery.com repo](https://github.com/jquery/learn.jquery.com).


jQuery Fundamentals will be serving as the basis for a new jQuery learning site
maintained by the jQuery project, and ongoing maintenance and support for this
content will transfer to the jQuery project. For more details, see my [blog
post](http://blog.rebeccamurphey.com/the-future-of-jquery-fundamentals-and-a-confe).

Please do not open issues on this repo; use the new jQuery Project repo instead.

## Using this Material ##

You are welcome to use this material according to the terms of the
[license](http://creativecommons.org/licenses/by-sa/3.0/us/); if
you're using it to teach a class, I'd love for you to let me know about it.

# Copyright & Licensing #

This material is Copyright &copy;2011 Rebecca Murphey and licensed under the
[Creative Commons Attribution-Share Alike 3.0 United States
license](http://creativecommons.org/licenses/by-sa/3.0/us/). You are free to
copy, distribute, transmit, and remix this work, provided you attribute the
work to Rebecca Murphey as the original author and reference [this
repository](http://github.com/rmurphey/jqfundamentals). If you alter,
transform, or build upon this work, you may distribute the resulting work only
under the same, similar or a compatible license. Any of the above conditions
can be waived if you get permission from the copyright holder. For any reuse or
distribution, you must make clear to others the license terms of this work. The
best way to do this is with a link to the [Creative Commons Attribution-Share
Alike 3.0 United States
license](http://creativecommons.org/licenses/by-sa/3.0/us/).
