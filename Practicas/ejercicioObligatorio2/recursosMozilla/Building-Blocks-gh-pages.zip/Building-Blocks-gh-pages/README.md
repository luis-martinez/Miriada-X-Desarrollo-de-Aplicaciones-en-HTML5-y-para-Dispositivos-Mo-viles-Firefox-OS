Building-Blocks
===============

Reusable components for Firefox OS

'style' and 'style_unstable' folders contain all Building Blocks from [gaia's repo](https://github.com/mozilla-b2g/gaia).
Feel free to use them, although we are using the word 'unstable' :) 
